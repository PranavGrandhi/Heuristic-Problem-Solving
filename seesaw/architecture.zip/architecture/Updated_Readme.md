# SeeSaw Game

## Starting the server
To begin the server run:
```php
php main.php 5000 20 7 7
```
The arguments are - <port_number> <board_length> <max_left> <max_right>


