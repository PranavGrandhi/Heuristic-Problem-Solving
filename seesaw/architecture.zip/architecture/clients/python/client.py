import json
from random import choice
from hps.clients import SocketClient
from time import sleep
import argparse
import ast

HOST = "localhost"
PORT = 5000


class NoTippingClient(object):
    def __init__(self, name, is_first):
        self.first_resp_recv = False
        self.name = name
        self.client = SocketClient(HOST, PORT)
        self.client.send_data(json.dumps({"name": self.name, "is_first": is_first}))
        response = json.loads(self.client.receive_data())
        # self.board_length = response['board_length']
        # self.max_left = response['max_left']
        # self.max_right = response['max_right']
        self.is_first = is_first

    def play_game(self):
        print("[INFO] Starting game ...")
        response = {}

        response = json.loads(self.client.receive_data())
        if "game_over" in response and response["game_over"] == "1":
            print("Game Over!")
            exit(0)

        other_board = []

        self.board_length = response["board_length"]
        self.max_left = response["max_left"]
        self.max_right = response["max_right"]
        if self.is_first == False:
            other_board = ast.literal_eval(response["left_board"])

        board = self.place(other_board)
        sboard = str(board)

        self.client.send_data(json.dumps({"board": sboard}))

    # TODO: complete the function here
    def place(self, other_board):
        length = self.board_length // 2
        solution = [0] * length
        if self.is_first:
            solution[0] = 1
        else:
            solution[length - 1] = 1
        return solution


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="")
    parser.add_argument(
        "--first",
        action="store_true",
        default=False,
        help="Indicates whether client should go first",
    )
    parser.add_argument("--ip", type=str, default="localhost")
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--name", type=str, default="Python Demo Client")
    args = parser.parse_args()

    HOST = args.ip
    PORT = args.port

    player = NoTippingClient(args.name, args.first)
    player.play_game()
