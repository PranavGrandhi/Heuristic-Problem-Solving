import socket
import random
import time
import sys

random.seed(11)

def send_move(socket, move: bool):
    msg = b"BET" if move else b"PASS"
    socket.send(msg)

def recv_result(socket):
    data = socket.recv(1024).decode()
    if data[:3] == "HIT":
        return True
    else:
        return False

def strategy():
    # FIXME
    return random.random() > 0.5

def main():
    host = 'localhost'
    port = 5555 if (len(sys.argv)<2) else int(sys.argv[1])

    client_socket = socket.socket()
    client_socket.connect((host, port))
    client_socket.send(b"PLAY Python Client")
    client_socket.recv(4)

    i = 0
    while i<10000:
        time.sleep(0.001)
        send_move(client_socket, strategy())
        recv_result(client_socket)
        i += 1

if __name__ == '__main__':
    main()
